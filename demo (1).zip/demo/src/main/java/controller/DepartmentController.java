package controller;

import entity.Department;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import service.DepartmentService;

public class DepartmentController {
    @Autowired
    private DepartmentService departmentService;

    // Save operation
    @PostMapping("/departments")

    public Department saveDepartment(
            @Validated @RequestBody Department department)
    {
        return departmentService.saveDepartment(department);
    }
}
